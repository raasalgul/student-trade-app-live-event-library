# DynamoDB Feed Package

This is a library created for my Master's course assignment 
to perform a RSS feed to my e-commerse app using dynamodb and
SQS queue in this package.